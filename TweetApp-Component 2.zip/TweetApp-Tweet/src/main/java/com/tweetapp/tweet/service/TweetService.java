package com.tweetapp.tweet.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.tweet.entity.Tweet;
import com.tweetapp.tweet.repository.TweetRepository;

@Service
public class TweetService {

	@Autowired
	private TweetRepository tweetRepository;

	public List<Tweet> getAllTweets() {
		return tweetRepository.findAll();
	}

	public List<Tweet> getAllTweetsOfUser(String email) {

		return tweetRepository.findByEmail(email);
	}

	public void postTweet(Tweet tweet) {
		tweet.setDate(new Date());
		tweet.setReplies(new ArrayList<>());
		tweetRepository.save(tweet);
	}

	public void updateTweet(String id, String message) {

		Tweet tweet = tweetRepository.findById(id).get();
		tweet.setDescription(message);
		tweet.setDate(new Date());
		tweetRepository.save(tweet);

	}

	public void deleteTweet(String id) {
		tweetRepository.deleteById(id);
	}

	public void likeTweet(String id) {
		Tweet tweet = tweetRepository.findById(id).get();
		tweet.setLikes(tweet.getLikes() + 1);
		tweetRepository.save(tweet);
	}

	public void replyTweet(String id, Tweet reply) {
		reply.setDate(new Date());
		reply.setReplies(new ArrayList<>());
		reply = tweetRepository.save(reply);
		Tweet tweet = tweetRepository.findById(id).get();
		List<Tweet> replies = tweet.getReplies();
		if (replies != null) {
			replies.add(reply);
		} else {
			replies = new ArrayList<>();
			replies.add(reply);
		}
		tweet.setReplies(replies);
		tweetRepository.save(tweet);
		tweetRepository.deleteById(reply.getId());

	}

}
