package com.tweetapp.user.entity;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class User {

	@NotBlank(message = "First Name cannot be empty !")
	private String firstName;
	@NotBlank(message = "Last Name cannot be empty !")
	private String lastName;
	@NotBlank(message = "Contact cannot be empty !")
	private String contactNo;
	@Id
	@Indexed(unique = true)
	@NotBlank(message = "Email cannot be empty !")
	@Pattern(regexp = "[A-Za-z0-9.]+@[a-zA-z]+.com", message = "Invalid Email ID !")
	private String email;
	@NotBlank(message = "Password cannot be empty !")
	@Size(min = 8,message = "Password should be more than 8 characters !")
	private String password;
	@NotBlank(message = "Confirm password cannot be empty !")
	private String confirmPassword;
	private int status;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(String firstName, String lastName, String contactNo, String email, String password,
			String confirmPassword, int status) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNo = contactNo;
		this.email = email;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.status = status;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

}
