package com.tweetapp.user.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.user.entity.LoginUser;
import com.tweetapp.user.entity.User;
import com.tweetapp.user.service.UserService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1.0/tweets")
public class UsersController {

	@Autowired
	private UserService userService;
	
	Logger logger=LoggerFactory.getLogger(UsersController.class);

	@PostMapping("/register")
	public ResponseEntity<String> register(@Valid @RequestBody User user) {

		if(userService.register(user)) {
			logger.info("Registration Successful - "+user.getEmail());
			return new ResponseEntity<String>("Sucess", HttpStatus.OK);
		}
		else {
			logger.info("Registration Failed - "+user.getEmail());
			return new ResponseEntity<String>("Failed", HttpStatus.OK);
		}
		
		//return userService.register(user)?new ResponseEntity<String>("Success", HttpStatus.OK):new ResponseEntity<String>("Failed", HttpStatus.OK);
	}

	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestBody LoginUser user) {
		//System.out.println("LOGIN api called !");

		if(userService.login(user.getEmail(), user.getPassword())) {
			logger.info("Login successful - "+user.getEmail());
			return new ResponseEntity<String>("Success", HttpStatus.OK);
		}
		else {
			logger.info("Login failed - "+user.getEmail());
			return new ResponseEntity<String>("Failed", HttpStatus.OK);
		}
		
//		return userService.login(user.getEmail(), user.getPassword())
//				? new ResponseEntity<String>("Success", HttpStatus.OK)
//				: new ResponseEntity<String>("Failed", HttpStatus.OK);
	}

	@PostMapping("/forgot")
	public ResponseEntity<String> forgotPassword(@RequestBody LoginUser user) {
		User user1 = new User();
		user1.setEmail(user.getEmail());
		user1.setPassword(user.getPassword());
		
		if(userService.forgotPassword(user.getEmail(), user.getPassword())) {
			logger.info("Password reset successfully - "+user.getEmail());
			return new ResponseEntity<String>("Success", HttpStatus.OK);
		}
		else {
			logger.info("Password reset failed - "+user.getEmail());
			return new ResponseEntity<String>("Failed", HttpStatus.OK);
		}
		
		//return userService.forgotPassword(user.getEmail(), user.getPassword()) ? "Success" : "Failed";

	}

	@GetMapping("/users/all")
	public List<String> getAllUsers() {
		return userService.getAllUsers();
	}

	@PostMapping("/logout")
	public ResponseEntity<String> logout(@RequestBody LoginUser user) {
		//System.out.println("LOGOUT api called !");

		if(userService.logOut(user.getEmail())) {
			logger.info("Logged out successfully - "+user.getEmail());
			return new ResponseEntity<String>("Success", HttpStatus.OK);
		}
		else {
			logger.info("Logout failed - "+user.getEmail());
			return new ResponseEntity<String>("Failed", HttpStatus.OK);
		}
		
//		return userService.logOut(user.getEmail()) ? new ResponseEntity<String>("Success", HttpStatus.OK)
//				: new ResponseEntity<String>("Failed", HttpStatus.OK);
	}

	@ResponseStatus(code = HttpStatus.BAD_GATEWAY)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getAllErrors().forEach((error) -> {
			String fieldName = ((FieldError) error).getField();
			String errorMessage = error.getDefaultMessage();
			errors.put(fieldName, errorMessage);
		});
		return errors;
	}
}
