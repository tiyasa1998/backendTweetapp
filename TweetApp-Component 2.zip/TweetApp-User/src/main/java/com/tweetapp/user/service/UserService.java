package com.tweetapp.user.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.user.entity.User;
import com.tweetapp.user.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public boolean register(User user) {
		try {
			user.setStatus(1);
			userRepository.save(user);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean login(String email, String password) {

		try {
			User user = userRepository.findById(email).get();

			if (userRepository.existsById(email)) {

				if (user.getPassword().equals(password)) {
					user.setStatus(0);
					userRepository.save(user);
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	public boolean logOut(String email) {

		List<User> users = userRepository.findAll();

		for (User u : users) {
			if (u.getEmail().equals(email)) {
				u.setStatus(1);
				userRepository.save(u);
				return true;
			}
		}
		return false;
	}

	public boolean forgotPassword(String email, String password) {

		if (userRepository.existsById(email)) {
			User user = userRepository.findById(email).get();
			user.setPassword(password);
			user.setConfirmPassword(password);
			userRepository.save(user);
			return true;
		}
		return false;
	}

	public List<String> getAllUsers() {

		List<String> users = new ArrayList<>();
		for (User user : userRepository.findAll()) {
			users.add(user.getEmail());
		}
		return users;
	}

	public int getStatus(String email) {

		return userRepository.findById(email).get().getStatus();

	}
}
